
<div class="p-3">

    <h5>Customize Admin</h5><hr class="mb-2"/>

    <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" role="switch" id="enable_mode" value="1">Enable Dark mode
    </div>
   
</div>

<?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/layouts/sidesetting.blade.php ENDPATH**/ ?>