
<?php $__env->startSection('page_title', 'Brand Report'); ?>
<?php $__env->startSection('style'); ?>
    <style>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-2">
                    <b>Brand Report </b>
                </div>
                
                <div class="col-md-2">
                    <select id="month_id" name="month_id" class="form-select form-select-sm select_chosen" >
                        <option selected disabled >Month</option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($selected_month == $list->id): ?>
                            <option  selected value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->month)); ?></option>
                            <?php else: ?>
                            <option  value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->month)); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="brand_id" name="brand_id" class="form-select form-select-sm select_chosen" >
                        <option selected disabled >Brand</option>
                        <?php $__currentLoopData = $all_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->brand_name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    
   
    
    <div class="row">
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

        

        <?php if(!(empty($list))): ?>
                <div class="col-md-12">
                    <div class="card row_filter" brand-id="<?php echo e($list['brand_id']); ?>">                        
                        <div class="card-header"><b><?php echo e(ucwords($list->brand_name)); ?></b></div>  
                       
                        <div class="card-body">
                            <div class="table-responsive">
                            <table class="table table-striped table-head-fixed table-sm">
                                <thead>
                                    <tr>
                                        <th>SN</th>
                                        <th>Style no</th>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Size</th>
                                        <th>Mrp</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $qty = 0;
                                        $total = 0;
                                    ?>
                                    <?php $__currentLoopData = $brand_detail[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                        <?php
                                            $qty = $qty + $item->qty ;
                                            $total = $total + $item->amount ;
                                        ?> 
                                       
                                             <td> <?php echo e(++$key1); ?></td>
                                            <td><?php echo e($item->sub_category); ?></td>
                                            <td><?php echo e($item->sub_category); ?></td>
                                            <td><?php echo e($item->qty); ?></td>
                                             <td><?php echo e($item->size); ?></td>
                                            <td><?php echo e($item->price); ?></td>
                                            
                                            
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                                <tfoot class="bg-dark">
                                    <tr>
                                        <td colspan="2"></td>
                                        <td colspan="">Total</td>
                                        <td colspan="2"><b><?php echo e($qty); ?></b></td>
                                        <td colspan=""><b><?php echo e($total); ?></b></td>
                                        
                                    </tr>
                                </tfoot>
                            </table>
                            </div>
                        </div>
                    </div>
                </div> 
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
           
   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        
        $(document).on('change','#from_date',function (e) {
            e.preventDefault();
            $from_date = $(this).val();            
            // alert($from_date);
            // brandReport($from_date);

        })
        $(".select_chosen").chosen({ width: '100%' });
            $(document).on('change','#brand_id', function (e) {
                e.preventDefault();
                const brand_id = $(this).val();
                // alert(brand_id);
                var row = $('.row_filter');
                row.hide()
                row.each(function(i, el) {
                    if($(el).attr('brand-id') == brand_id) {
                        $(el).show();
                    }
                });
            });

            $(document).on('change','#month_id', function (e) {
                var  month_id = $(this).val();
                var url = "brand-report";
                location.replace(`${url}/${month_id}`);
                
              
            });
            
     });

          
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/report/brand_report.blade.php ENDPATH**/ ?>