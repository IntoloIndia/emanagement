
<?php $__env->startSection('page_title', 'Sales Report'); ?>
<?php $__env->startSection('style'); ?>
    <style>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    

                    <div class="col-md-3"><b>Sales Report</b></div>
                    <div class="col-md-3">
                        <input type="date"  id="from_date" class="form-control form-control-sm" value='<?php echo e(date('d-m-Y', strtotime('-3 months'))); ?>'>
                    </div>
                    <div class="col-md-3">
                        <input type="date"  id="to_date" class="form-control form-control-sm" value='<?php echo e(date('d-m-Y')); ?>'>
                    </div>
                    <div class="col-md-3">
                        <input type="month"  id="month" class="form-control form-control-sm" value="<?php echo e(date('Y-m-d')); ?>">
                    </div>
                </div>
               
            </div>
            <div class='card-body table-responsive' style='height: 500px;'>
                <div id="show_sales_report_detail"></div>
                
              

                
            </div> 
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><b>Sales Payment</b></div>
            <div class='card-body ' style='height: 500px;'>              
                <div class="row mt-2">                   
                    <div class="col-md-4">
                        <label>Total Qty</label>
                        <input type="text"  id="total_qty" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Price</label>
                        <input type="text"  id="total_price" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Discount</label>
                        <input type="text"  id="total_discount" class="form-control form-control-sm" disabled>  
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-4">
                        <label>Online</label>
                        <input type="text"  id="online" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Cash</label>
                        <input type="text"  id="cash" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Card</label>
                        <input type="text"  id="card" class="form-control form-control-sm" disabled>  
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-4">
                        <label>Received</label>
                        <input type="text"  id="received_amount" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Balance</label>
                        <input type="text" id="balance_amount" class="form-control form-control-sm" disabled>  
                    </div>
                    <div class="col-md-4">
                        <label>Total Amount</label>
                        <input type="text"  id="total_amount" class="form-control form-control-sm" disabled>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>    
        $(document).ready(function () {
            
          
            // salesReportDetail();
            // salesReportDetail(month ='');
            $(document).on('change','#month', function (e) {
                var month = $(this).val();
                alert(month);
                salesReportDetail(month);
            });
        });
        
    // function salesReportDetail()
    function salesReportDetail(month)
    {
        $.ajax({
            type: "get",
            dataType: "json",
            url: "sales-report-detail/"+month,
            success: function (response) {
                console.log(response);
                if(response.status == 200){
                    $('#show_sales_report_detail').html("");
                    $('#show_sales_report_detail').append(response.html);
                    $('#total_qty').val(response.total_qty);
                    $('#total_price').val(response.total_price);
                    $('#total_discount').val(response.total_discount);
                    $('#online').val(response.online);
                    $('#cash').val(response.cash);
                    $('#card').val(response.card);
                    $('#received_amount').val(response.received_amount);
                    $('#total_amount').val(response.amount);
                    $('#balance_amount').val(response.total_balance_amount);
                }
            }
        });
    }
    function getSalesPayment($customer_id = '')
    // function getSalesPayment($customer_id = '',month)
    {
        var month = $(this).val();
        // alert(month);
        $.ajax({
            type: "get/"+$customer_id,
            // type: "get/"+$customer_id+ "/"+ month,
            dataType: "json",
            url: "get-sales-payment",
            success: function (response) {
                console.log(response);
                if(response.status == 200){                  
                    $('#month').val($month);
                    getSalesPayment(customer_id = '');
                    // getSalesPayment(customer_id = '',month);
                }
            }
        });
    }


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/report/sales_report.blade.php ENDPATH**/ ?>