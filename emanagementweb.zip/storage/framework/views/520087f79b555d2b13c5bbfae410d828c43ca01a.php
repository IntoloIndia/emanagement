
<?php $__env->startSection('page_title', '404 Page Not Found'); ?>


<?php $__env->startSection('content'); ?>

    <div class="error-page pt-5">
        <h2 class="headline text-warning"> 404</h2>
        <div class="error-content">
            <h2><i class="fas fa-exclamation-triangle text-warning"></i> Oops! Page not found.</h2>
            <p class="pt-3">
                We could not find the page you were looking for.
                Meanwhile, you may <a href="dashboard">return to dashboard</a> or enter correct input.
            </p>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/404.blade.php ENDPATH**/ ?>