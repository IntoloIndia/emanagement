
<?php $__env->startSection('page_title', 'Manage Stock'); ?>

<?php $__env->startSection('style'); ?>
    <style>
    #colorinput{
        border: none;
    }
    </style>
<?php $__env->stopSection(); ?>;

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-3">
            <div class="card">
                <div class="card-header">
                    <b>Category </b>
                </div>
                <div class="card-body table-responsive p-0" style="height: 250px;">
                    <table class="table table-head-fixed text-nowrap">
                        <thead>
                            <tr>
                                <th >SN</th>
                                <th >Category</th>
                                <th >Qty</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo e($count = ""); ?>

                            
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $result = stockItemQtyByCategory($item['id']);
                                ?> 
                                    <tr>
                                        <th scope="row"><?php echo e(++$key); ?></th>
                                        <td><?php echo e(ucwords($item['category'])); ?></td>
                                        <td><?php echo e($result['total_qty']); ?></td>
                                        
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6"><b>Sub Categoty</b></div>
                        <div class="col-md-6">
                            <select id="category_id" name="category_id" class="form-select form-select-sm select_chosen" >
                                <option selected disabled >Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="card-body table-responsive p-0" style="height: 250px;">
                    <table class="table table-head-fixed text-nowrap">
                        <thead>
                            <tr>
                                <th >SN</th>
                                <th >Sub Categoty</th>
                                <th >Qty</th>
                                
                            </tr>
                        </thead>
                        <tbody >
                            <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $result = stockItemQtyBySubCategory($item['id']);
                                 
                                    
                                ?> 
                                <tr class="row_filter" category-id="<?php echo e($item['category_id']); ?>">
                                    <th scope="row"><?php echo e(++$key); ?></th>
                                    <td><?php echo e(ucwords($item['sub_category'])); ?></td>
                                    <td><?php echo e($result['total_qty']); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <div class="col-lg-9">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-2 "><b>Products</b></div>
                    </div>
                     <div class="row">
                        <div class="col-md-2  offset-1">
                            <select id="filter_category_id" class="form-select form-select-sm select_chosen" onchange="getSubCategoryByCategory(this.value);" >
                                <option selected disabled >Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select id="sub_category_id" class="form-select form-select-sm select_chosen">
                                <option selected disabled >Choose...</option>
                                
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select id="brand_id" class="form-select form-select-sm select_chosen" >
                                <option selected value="0">Brand</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->brand_name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <select id="style_no_id" class="form-select form-select-sm select_chosen" >
                                <option selected value="0" >Style No</option>
                                <?php $__currentLoopData = $get_style_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" ><?php echo e($list->style_no); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select id="color" data-placeholder='Select color' class="form-select form-select-sm select_chosen" >
                                <option selected value="" disabled ></option>
                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->color); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-1 text-end position-relative" >
                            <i class="fas fa-redo cursor-pointer position-absolute top-50 start-50 translate-middle" id="reset_products"></i>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div id="show_product"></div>                    
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>;

<?php $__env->startSection('script'); ?>
    <script>

        $(document).ready(function () {
            $(".select_chosen").chosen({ width: '100%' });
            showProduct();
            $(document).on('change','#category_id', function (e) {
                e.preventDefault();
                const category_id = $(this).val();
                var row = $('.row_filter');
                row.hide()
                row.each(function(i, el) {
                    if($(el).attr('category-id') == category_id) {
                        $(el).show();
                    }
                })

                showProduct(); 
            });

            $(document).on('change','#filter_category_id', function (e) {
                showProduct();
            });     
            $(document).on('change','#sub_category_id', function (e) {
                showProduct();
            });     
            $(document).on('change','#brand_id', function (e) {
                showProduct();
            });
            $(document).on('change','#style_no_id', function (e) {
                showProduct();
            });
            $(document).on('change','#color', function (e) {
                showProduct();
            });
            $(document).on('click','#reset_products', function (e) {
                window.location.reload();
            });

        });

        function showProduct()
        {
            var category_id = $('#filter_category_id').val();
            var sub_category_id = $('#sub_category_id').val();
            var brand_id = $('#brand_id').val();
            var style_no_id = $('#style_no_id').val();
            var color = $('#color option:selected').text();

            $.ajax({
                type: "get",
                dataType: "json",
                url: "show-product/"+ category_id + "/" + sub_category_id + "/" + brand_id + "/" + style_no_id + "/" + color,
                success: function (response) {
                    // console.log(response);
                    if(response.status == 200){
                        $('#show_product').html("");
                        $('#show_product').append(response.html)
                    }
                }
            });
        }

            
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/manage_stock.blade.php ENDPATH**/ ?>