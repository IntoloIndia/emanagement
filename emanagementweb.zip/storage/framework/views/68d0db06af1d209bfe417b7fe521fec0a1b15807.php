
<?php $__env->startSection('page_title', 'Barcode'); ?>
<?php $__env->startSection('style'); ?>
<style>
    /* .colorbox{
        width: 200px !important;
        height: 200px !important;   
        border: 1px solid black;
        background-color: red

    } */
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
     <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-md-1">
                    <b>Barcodes</b>
                </div>
            
                <div class="col-md-2 ">
                         <select id="filter_category_id" class="form-select form-select-sm select_chosen" onchange="getSubCategoryByCategory(this.value);" >
                        <option selected disabled >Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>" ><?php echo e($list->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="sub_category_id" class="form-select form-select-sm select_chosen">
                        <option selected disabled >Choose...</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="brand_id" class="form-select form-select-sm select_chosen" >
                        <option selected disabled value="0">Brand</option>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->brand_name)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="style_no_id" data-placeholder='Style no' class="form-select form-select-sm select_chosen">
                        <option selected disabled value="0">Style no</option>
                        <?php $__currentLoopData = $get_style_no; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>" ><?php echo e($list->style_no); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="color" data-placeholder='Select color' class="form-select form-select-sm select_chosen" >
                        <option selected value="" disabled ></option>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($list->id); ?>"><?php echo e($list->color); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-1 text-end position-relative" >
                    <i class="fas fa-redo cursor-pointer position-absolute top-50 start-50 translate-middle" id="reset_filter"></i>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div id="show_filter_barcode"></div>
            
        </div> 
    </div>

    
                 
                            
                             
                 
            
        
     
 
   


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    $(document).ready(function () {
        $(".select_chosen").chosen({ width: '100%' });

        $(document).on('click','#reset_filter', function (e) {
                window.location.reload();
        });
        
        $(document).on('change','#sub_category_id', function (e) {
            filterBarcode();
        });
        $(document).on('change','#brand_id', function (e) {
            filterBarcode();
        });
        $(document).on('change','#style_no_id', function (e) {
            filterBarcode();
        });
        $(document).on('change','#color', function (e) {
            filterBarcode();
        });

        $(document).on('click','.print', function (e) {
            var print_section = $(this).attr('print-section');
            printBarcode(print_section);
        });

        // $("#sub_category_id").change(function() {
        //     var filterValue = $(this).val();
        //     var row = $('.filter_row'); 
        //     row.hide()
        //     row.each(function(i, el) {
        //         if($(el).attr('row-value') == filterValue) {
        //             $(el).show();
        //         }
        //     })
        // });



    });
    

    // function printBarcode(){
        
    //     var backup = document.body.innerHTML;
    //     var div_content = document.getElementById("show_barcode_body").innerHTML;
    //     document.body.innerHTML = div_content;
    //     window.print();
    //     document.body.innerHTML = backup;


    //     // const section = $("section");
    //     // // const modalBody = $("#show_barcode_body").detach();
    //     // const modalBody = document.getElementById("barcode_body").innerHTML;

    //     // section.empty();
    //     // section.append(modalBody);
    //     // window.print();
    //     // window.location.reload();

    //     // var print_div = document.getElementById("show_barcode_body");
    //     // // var print_div = document.getElementById("barcode_body");
    //     // var print_area = window.open();
    //     // print_area.document.write(print_div.innerHTML);
    //     // print_area.document.close();
    //     // print_area.focus();
    //     // print_area.print();
      
    //     window.location.reload();
    // }

    function filterBarcode()
    {
        var sub_category_id = $('#sub_category_id').val();
        var brand_id = $('#brand_id').val();
        var style_no_id = $('#style_no_id').val();
        var color = $('#color option:selected').text();

        $.ajax({
            type: "get",
            dataType: "json",
            url: "filter-barcode/"+ sub_category_id + "/" +brand_id + "/" + style_no_id + "/" + color,
            success: function (response) {
                // console.log(response);
                if(response.status == 200){
                    $('#show_filter_barcode').html("");
                    $('#show_filter_barcode').append(response.html)
                }
            }
        });
    }


</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/barcode.blade.php ENDPATH**/ ?>