
<?php $__env->startSection('page_title', 'Offer Report'); ?>
<?php $__env->startSection('style'); ?>
    <style>
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <div class="content-header">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h3 class="m-0"><b>Offer Report</b></h3>
            </div>
            <div class="col-sm-6">
                <div class="d-grid gap-2 d-md-flex justify-content-md-end ">
                    
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6"><b>Offers</b></div>
                        <div class="col-md-6">
                            <select  name="offer_type" id="offer_type" class="form-select select_chosen_100">
                                <option selected disabled>Offer Type</option>
                                <option value="<?php echo e(MyApp::PERCENTAGE); ?>">PERCENTAGE</option>
                                <option value="<?php echo e(MyApp::VALUES); ?>">VALUES</option>
                                <option value="<?php echo e(MyApp::PICES); ?>">PICES</option>
                                <option value="<?php echo e(MyApp::SLAB); ?>">SLAB</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class='card-body table-responsive' style='height: 500px;'>

                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php
                            $offer_type = '';
                            if ($list->offer_type==MyApp::PERCENTAGE) {
                                $offer_type = 'PERCENTAGE';
                            } else if ($list->offer_type==MyApp::VALUES) {
                                $offer_type = 'VALUES';
                            }elseif ($list->offer_type==MyApp::PICES) {
                                $offer_type = 'PICES';
                            }elseif ($list->offer_type==MyApp::SLAB) {
                                $offer_type = 'SLAB';
                            } 
                            
                        ?>
                        <div class='card card-outline card-primary offer' offer-id='<?php echo e($list->id); ?>'>
                            <div class='card-header'>
                                <h3 class='card-title'><?php echo e($offer_type); ?></h3>
                            </div>
                            <div class='card-body'>
                                <div class="row m-0">
                                    <div class="col-md-12 text-center" style="font-size: 18px">
                                        <b><?php echo e(($list->offer_section == MyApp::PRODUCT) ? 'PRODUCT' : 'STORE'); ?></b>                           
                                    </div>
                                </div>
                                <div class="row text-center">
                                    <div class="col-md-4">
                                        <b style="font-size: 22px; color:red;"><?php echo e(ucwords($list->summary)); ?></b>
                                    </div>
                                    <div class="col-md-4">
                                        <b style="font-size: 22px; color:red;"><?php echo e($list->discount_offer); ?>%</b>
                                    </div>
                                    <div class="col-md-4">
                                        <b style="font-size: 22px; color:red;">Off</b>
                                    </div>
                                </div>
                            </div>
                            <div class='card-footer  ' style="background-color:#A3E4D7">
                                <div class='row'>
                                    <div class='col-md-6'>
                                        <span><b><?php echo e(date('d-m-Y',strtotime($list->offer_from))); ?></b></span></b>
                                    </div>
                                    <div class='col-md-6 text-end'>
                                        <span><b><?php echo e(date('d-m-Y',strtotime($list->offer_to))); ?></b></span></b>
                                    </div>
                                </div>
                            </div>
                        </div>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-2"><b>Offers</b></div>
                        <div class="col-md-2">
                            <select id="filter_category_id" class="form-select form-select-sm select_chosen" onchange="getSubCategoryByCategory(this.value);" >
                                <option selected disabled >Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" ><?php echo e(ucwords($list->category)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select id="sub_category_id" class="form-select form-select-sm select_chosen">
                                <option selected disabled >Choose...</option>
                                
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select id="brand_id" class="form-select form-select-sm select_chosen" >
                                <option selected value="0">Brand</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e(ucwords($list->brand_name)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <select id="style_no_id" class="form-select form-select-sm select_chosen" >
                                <option selected value="0" >Style No</option>
                                <?php $__currentLoopData = $style_nos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>" ><?php echo e($list->style_no); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class='card-body table-responsive' style='height: 500px;'>
                    <div id="show_offer_report"></div> 
                    <table class="table table-head-fixed text-nowrap">
                        <thead>
                            <tr>
                                <th>SN</th>
                                <th>Category</th>
                                <th>Sub Category</th>
                                <th>Brand</th>
                                <th>Style No</th>
                            </tr>
                        </thead>
                        <?php
                            $count = 0;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $bill_invoice_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="row_filter search_data" city-id="<?php echo e($list->id); ?>">
                                    <td><?php echo e(++$count); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    
                                    
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {
            $(".select_chosen_100").chosen({ width: '100%' });

            $(document).on('click',".offer",function(e){
                e.preventDefault();

                var offer_id = $(this).attr('offer-id');
                
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\emanagementweb\resources\views/report/offer_report.blade.php ENDPATH**/ ?>