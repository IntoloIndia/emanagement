<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchaseReturnsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_returns', function (Blueprint $table) {
            $table->id();
            $table->integer('supplier_id')->default(0);
            // $table->string('gst_no')->nullable();
            // $table->string('supplier_address')->nullable();
            // $table->string('supplier_code')->nullable();
            $table->date('create_date')->nullable();
            $table->string('create_time')->nullable();
            $table->date('release_date')->nullable();
            $table->string('release_time')->nullable();
            $table->integer('release_status')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_returns');
    }
}
